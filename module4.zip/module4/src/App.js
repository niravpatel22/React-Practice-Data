// import logo from './logo.svg';
// import './App.css';

import { useState } from "react";

// function App() {

//   const color ="pink";
//   return (
//    <>
//     <h1>Color:{(color=='red')? "blue":"red"}</h1>
//    </>
//   );
// }


function App()
{
  // const color ="red";

  const [Name,SetName] = useState("Nirav");
  const changeColor =   ()=>{   
    
  
      
  // if(color=='red')
  // {
  //   alert(color)
  // }
  // else 
  // {
  //   alert(color)
  // }

      }

      return (
        <>
        <h1>Name :{Name}</h1>
        <button onClick={()=>{SetName("Krishiv")}}>Krishiv</button>
        <button onClick={()=>{SetName("Dhwani")}}>Dhwani</button>
        <button onClick={()=>{SetName("Dhairya")}}>Dhairya</button>
        <button onClick={()=>{SetName("Hems")}}>Hems</button>



        </>
      );

     
  }



export default App;
