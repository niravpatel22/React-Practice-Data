import React, { useState } from "react";

// function Student()
// {
//     const [name,course] = useState('Nirav');

//     return(
//         <h1>Name:{name}</h1>
//     )
// }


// function Student()
// {
//     const [courseName,course] = useState('WD');

//     return(
//         <>
//         <h1> my course is {courseName}</h1>
//         <button onClick={()=>course('Web Designing...!')}>Change Course</button>

       
//         <button onClick={()=>course('Frontend Development...!')}>Change Course</button>

       
//         <button onClick={()=>course('JAVA...!')}>Change Course</button>

       
//         <button onClick={()=>course('Python...!')}>Change Course</button>
//         </>
//     )
// }


// function Student()
// {
//     const [name,setName] = useState('Nirav');
//     const [age,setAge] = useState(33);
//     const [course,setCourse] = useState('React JS...!');

//     return(
//         <>
//             <h1>Hello : {name}</h1>
//             <h2>Age : {age}</h2>
//             <h2>Course :{course}</h2>        
//         </>
//     )

// }

// function Student()
// {
//     const [student,details] = useState({

//         Name:"Nirav",
//         Age : 36,
//         "Course" :"React..!"
//     });
   

//     return(
//         <>
//             <h1>Hello : {student.Name}</h1>
//             <h2>Age : {student.Age}</h2>
//             <h2>Course :{student.Course}</h2>        
//         </>
//     )

// }


// function Student()
// {
//     const [student,details] = useState({

//         Name:"Nirav",
//         Age : 36,
//         "Course" :"React..!"
//     });

//     const updateDetails = () => {
//         // details(e => { return { e, Course: "WD" } });

//         details(e => { return { ...e, Course: "WD"} });
//         // details(e => { return { ...e, Course: "WD" ,Age:"33"} });
//       }
   

//     return(
//         <>
//             <h1>Hello : {student.Name}</h1>
//             <h2>Age : {student.Age}</h2>
//             <h2>Course :{student.Course}</h2> 

//             <button onClick={updateDetails}>Change Details</button>       
//         </>
//     )

// }
export default Student;